class Dog:
  def hi(self):
    print("bark!")