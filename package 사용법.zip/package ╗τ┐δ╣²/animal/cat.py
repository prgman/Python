class Cat:
  def hi(self):
    print("meou!")