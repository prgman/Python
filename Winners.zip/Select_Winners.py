import random
import time

entries = []

with open("participants.csv") as f:
    for line in f:
        timestamp,email,name,suggestion = line.split(",")
        entries.append({
            "timestamp": timestamp,
            "email": email,
            "name": name,
            "suggestion": suggestion,
        })

for e in entries:
    print(e["name"])

print(len(entries))

uniq_entries = []
used_names = set()

for e in entries:
        if e["name"] not in used_names:
            used_names.add(e['name'])
            uniq_entries.append(e)

print(len(uniq_entries))

winners = random.sample(uniq_entries, 100)
with open("winners.txt", "w+") as f2:
    for winner in winners:
        f2.write("%s,%s,%s" %(winner["name"], winner["email"],winner["suggestion"]))

for i, w in enumerate(winners):
    time.sleep(0.5)
    print("%d. %s님, 축하드립니다.!" % (i, w["name"]))